seeded-region-growing
=====================

Seeded region growing in n-dimensional grid graphs, in linear time (C++ and MATLAB)